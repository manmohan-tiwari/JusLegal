// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'JusLegal';

  @override
  String get home => 'Home';

  @override
  String get myCases => 'My Cases';

  @override
  String get authorities => 'Authorities';

  @override
  String get settings => 'Settings';

  @override
  String get preferences => 'Preferences';

  @override
  String get appInfo => 'App Info';

  @override
  String get appNameLabel => 'App Name';

  @override
  String get appVersion => 'App Version';

  @override
  String get legal => 'Legal';

  @override
  String get privacyPolicy => 'Privacy Policy';

  @override
  String get terms => 'Terms';

  @override
  String get website => 'Website';

  @override
  String get disclaimer => 'Disclaimer';

  @override
  String get account => 'Account';

  @override
  String get deleteAccount => 'Delete account';

  @override
  String get deleteAccountTitle => 'Delete account?';

  @override
  String get deleteAccountMessage =>
      'This will permanently delete your account, all saved cases, and your Firebase authentication record. This action CANNOT be undone.';

  @override
  String get deleteAccountConfirmMessage =>
      'To confirm, type DELETE in the field below. You may also be asked to re-authenticate for security.';

  @override
  String get typeDeleteToConfirm => 'Type DELETE to confirm';

  @override
  String get typeDeleteHint => 'DELETE';

  @override
  String get deleteButtonDisabledHint => 'Type DELETE exactly to enable';

  @override
  String get deletingAccount => 'Deleting your account...';

  @override
  String get accountDeletedSuccess =>
      'Your account and all data have been permanently deleted.';

  @override
  String get delete => 'Delete';

  @override
  String get cancel => 'Cancel';

  @override
  String get ok => 'OK';

  @override
  String get unableToDeleteAccount =>
      'Unable to delete account. Please try again.';

  @override
  String get reauthenticationFailed =>
      'Re-authentication failed. Please try again.';

  @override
  String get reauthenticationRequired =>
      'For security, please sign in again before deleting your account.';

  @override
  String get requiresRecentLogin =>
      'Your session is too old. Please sign in again to delete your account.';

  @override
  String get accountDataDeletionTitle => 'Account & Data Deletion';

  @override
  String get accountDataDeletionDesc =>
      'You can permanently delete your account and all associated data at any time.';

  @override
  String get accountDataDeletionInApp =>
      'In the app: go to Settings > Account > Delete Account. Follow the confirmation steps to remove your account, saved cases, and authentication record.';

  @override
  String get accountDataDeletionEmail =>
      'By email: send a deletion request to support@juslegal.app from your registered email address. We will process your request within a reasonable timeframe.';

  @override
  String get legalDisclaimer => 'Legal Disclaimer';

  @override
  String get settingsTooltip => 'Settings';

  @override
  String get homeHeroHeadline1 => 'Know Your Rights.';

  @override
  String get homeHeroHeadline2 => 'Take Action.';

  @override
  String get homeHeroBody =>
      'Get instant AI-powered legal guidance for your consumer issues.';

  @override
  String get getStarted => 'Get Started';

  @override
  String get exploreLegalCategories => 'EXPLORE LEGAL CATEGORIES';

  @override
  String get noCategoriesAvailable => 'No categories available';

  @override
  String get pleaseCheckBackLaterForLegalTopics =>
      'Please check back later for legal topics.';

  @override
  String get showAllCategories => 'Show All Categories';

  @override
  String get aiChatLegalQueriesAndAnalysis =>
      'AI CHAT, LEGAL QUERIES AND ANALYSIS';

  @override
  String get instantAIPoweredLegalGuidanceAtYourFingertips =>
      'Instant AI-powered legal guidance at your fingertips';

  @override
  String get documentsAndContracts => 'DOCUMENTS AND CONTRACTS';

  @override
  String get generateReviewAndNegotiateLegalDocumentsWithAI =>
      'Generate, review and negotiate legal documents with AI';

  @override
  String get whyChooseJuslegal => 'WHY CHOOSE JUSLEGAL';

  @override
  String get aiPoweredAnalysis => 'AI-Powered Analysis';

  @override
  String get aiPoweredAnalysisDesc =>
      'Get instant legal analysis based on your situation';

  @override
  String get legalCategoriesCount => '10+ Legal Categories';

  @override
  String get legalCategoriesCountDesc => 'Covers all major consumer issues';

  @override
  String get expertAuthorities => 'Expert Authorities';

  @override
  String get expertAuthoritiesDesc =>
      'Direct access to official regulatory bodies';

  @override
  String get documentGeneration => 'Document Generation';

  @override
  String get documentGenerationDesc =>
      'Professional complaint letters and notices';

  @override
  String get aiGuidanceOnlyNotLegalAdvice =>
      'AI-generated guidance only. Not legal advice. ';

  @override
  String get learnMore => 'Learn More';

  @override
  String get open => 'Open';

  @override
  String get there => 'there';

  @override
  String get toolAiLawyerChatTitle => 'AI Lawyer Chat';

  @override
  String get toolAiLawyerChatDesc =>
      'Ask legal questions in natural conversation';

  @override
  String get toolLegalAdviceTitle => 'Legal Advice Q&A';

  @override
  String get toolLegalAdviceDesc =>
      'Pre-built questions with AI-generated answers';

  @override
  String get toolCaseAnalysisTitle => 'Case Analysis';

  @override
  String get toolCaseAnalysisDesc =>
      'Strengths, weaknesses & next steps for your case';

  @override
  String get toolLegalTermsTitle => 'Legal Terms';

  @override
  String get toolLegalTermsDesc =>
      'Plain-language dictionary of legal terminology';

  @override
  String get toolLegalWritingTitle => 'Legal Writing';

  @override
  String get toolLegalWritingDesc =>
      'Generate complaint letters, notices & agreements';

  @override
  String get toolDocumentCreationTitle => 'Document Creation';

  @override
  String get toolDocumentCreationDesc =>
      'Fill AI-assisted templates as PDF or text';

  @override
  String get toolDocumentReviewTitle => 'Document Review';

  @override
  String get toolDocumentReviewDesc =>
      'Upload a doc - AI finds red flags & key clauses';

  @override
  String get toolContractNegotiationTitle => 'Contract Negotiation';

  @override
  String get toolContractNegotiationDesc =>
      'AI flags unfair clauses & suggests amendments';

  @override
  String get login => 'Login';

  @override
  String get register => 'Register';

  @override
  String get yourLegalRightsProtected => 'Your legal rights, protected';

  @override
  String get secureAccessPortal => 'Secure Access Portal';

  @override
  String get newToJusLegal => 'New to JusLegal? ';

  @override
  String get footerCopyright => '© JusLegal';

  @override
  String get continueWith => 'Continue with';

  @override
  String get continueWithGoogle => 'Continue with Google';

  @override
  String get continueWithApple => 'Continue with Apple';

  @override
  String get signInInstantlyWithPhoneOtp =>
      'Sign in instantly with Phone (OTP)';

  @override
  String get enterYourPhoneNumber => 'Enter your phone number';

  @override
  String get sendOtp => 'Send OTP';

  @override
  String get continueWithEmail => 'Continue with Email';

  @override
  String get needHelp => 'Need help?';

  @override
  String get byContinuingYouAgreeToOur => 'By continuing you agree to our ';

  @override
  String get termsAndPrivacy => 'Terms & Privacy Policy';

  @override
  String get authenticating => 'Authenticating...';

  @override
  String get validPhoneNumberError =>
      'Please enter a valid 10-digit phone number';

  @override
  String get otpSentSuccessfully => 'OTP sent successfully';

  @override
  String get phoneNumberVerifiedSuccessfully =>
      'Phone number verified successfully';

  @override
  String get appleSignInSoon => 'Apple sign-in will be available soon.';

  @override
  String get unableToOpenLink => 'Unable to open this link. Please try again.';

  @override
  String get tooManyOtpRequests =>
      'Too many attempts. Please wait before requesting another OTP.';

  @override
  String reachUsAt(String email) {
    return 'Reach us at $email';
  }

  @override
  String get verifyYourNumber => 'Verify your number';

  @override
  String otpSentTo(String phoneNumber) {
    return 'OTP sent to +91 $phoneNumber';
  }

  @override
  String get verifyOtp => 'Verify OTP';

  @override
  String get didntReceiveOtp => 'Didn\'t receive OTP? ';

  @override
  String resendIn(String time) {
    return 'Resend in $time';
  }

  @override
  String get resend => 'Resend OTP';

  @override
  String get otpExpired => 'OTP has expired. Please request a new one.';

  @override
  String get verifyingOtp => 'Verifying OTP...';

  @override
  String get enterOtpDigits => 'Please enter all 6 digits of the OTP';

  @override
  String get otpResentSuccessfully => 'OTP resent successfully';

  @override
  String get verifyYourNumberSubtitle =>
      'Enter the 6-digit code sent to your phone.';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get enterYourEmail => 'Enter your email';

  @override
  String get enterYourPassword => 'Enter your password';

  @override
  String get confirmYourPassword => 'Confirm your password';

  @override
  String get forgotPassword => 'Forgot Password?';

  @override
  String get backToLoginOptions => 'Back to Login Options';

  @override
  String get pleaseEnterYourEmail => 'Please enter your email';

  @override
  String get pleaseEnterValidEmail => 'Please enter a valid email address';

  @override
  String get pleaseEnterYourPassword => 'Please enter your password';

  @override
  String get passwordMustBeAtLeast6Characters =>
      'Password must be at least 6 characters';

  @override
  String get passwordStrengthRequirements =>
      'Password must be at least 8 characters and include uppercase, lowercase, a number, and a special character.';

  @override
  String get pleaseConfirmYourPassword => 'Please confirm your password';

  @override
  String get passwordsDoNotMatch => 'Passwords do not match';

  @override
  String get loginSuccessful => 'Login successful!';

  @override
  String get accountCreatedSuccessfully => 'Account created successfully!';

  @override
  String get emailVerificationRequired =>
      'Please verify your email address before signing in.';

  @override
  String get verifyYourEmail => 'Verify your email';

  @override
  String verificationEmailSent(String email) {
    return 'We sent a verification link to $email.';
  }

  @override
  String get checkVerification => 'I verified my email';

  @override
  String get resendVerificationEmail => 'Resend verification email';

  @override
  String get verificationEmailResent => 'Verification email sent again.';

  @override
  String get emailVerifiedSuccessfully => 'Email verified successfully!';

  @override
  String get emailNotVerifiedYet => 'Your email is not verified yet.';

  @override
  String get sending => 'Sending...';

  @override
  String passwordResetEmailSent(String email) {
    return 'Password reset email sent to $email';
  }

  @override
  String get yourLegalAnalysis => 'Your Legal Analysis';

  @override
  String get noAnalysisAvailable => 'No analysis available';

  @override
  String get somethingWentWrong => 'Something went wrong';

  @override
  String get retry => 'Retry';

  @override
  String get analysisIncomplete => 'Analysis incomplete';

  @override
  String get updatingAnalysis => 'Updating analysis...';

  @override
  String get confidenceScore => 'Confidence Score';

  @override
  String get strongCase => 'Strong case';

  @override
  String get moderateCase => 'Moderate';

  @override
  String get weakCase => 'Weak';

  @override
  String get yourRights => 'Your Rights';

  @override
  String get recommendedSteps => 'Recommended Steps';

  @override
  String get relevantLaws => 'Relevant Laws';

  @override
  String get authoritiesToContact => 'Authorities to Contact';

  @override
  String get generateComplaint => 'Generate Complaint';

  @override
  String get saveCase => 'Save Case';

  @override
  String get caseSavedToMyCases => 'Case saved to My Cases';

  @override
  String get unableToSaveCase => 'Unable to save case. Please try again.';

  @override
  String get noAuthoritiesListedForThisCase =>
      'No authorities listed for this case.';

  @override
  String get unknown => 'Unknown';

  @override
  String get visitWebsite => 'Visit Website';

  @override
  String get learnMoreAction => 'Learn More';

  @override
  String get updatingAnalysisStatus => 'Updating analysis...';

  @override
  String get complaintLetter => 'Complaint Letter';

  @override
  String get recipient => 'Recipient';

  @override
  String get selectTone => 'Select Tone';

  @override
  String get letterPreview => 'Letter Preview';

  @override
  String get lockLetter => 'Lock Letter';

  @override
  String get editLetter => 'Edit Letter';

  @override
  String get notSatisfied => 'Not satisfied?';

  @override
  String get copyText => 'Copy Text';

  @override
  String get downloadPrintPdf => 'Download / Print PDF';

  @override
  String get regenerate => 'Regenerate';

  @override
  String get copiedToClipboard => 'Copied to clipboard';

  @override
  String get pdfDownloadedSuccessfully => 'PDF Downloaded successfully';

  @override
  String failedToDownloadPdf(String error) {
    return 'Failed to download PDF: $error';
  }

  @override
  String get pleaseAnalyzeYourProblemFirst =>
      'Please analyze your problem first.';

  @override
  String get concernedAuthority => 'Concerned Authority';

  @override
  String get formal => 'Formal';

  @override
  String get assertive => 'Assertive';

  @override
  String get concise => 'Concise';

  @override
  String get documentCreation => 'Document Creation';

  @override
  String get availableForms => 'AVAILABLE FORMS';

  @override
  String get browseAndSelectFrom10OfficialIndianLegalForms =>
      'Browse and select from 10 official Indian legal forms';

  @override
  String get aiEnhancement => 'AI Enhancement';

  @override
  String get letAiImproveLanguageAndFormatting =>
      'Let AI improve language and formatting';

  @override
  String get fillDetails => 'FILL DETAILS';

  @override
  String get generating => 'Generating...';

  @override
  String get generateForm => 'Generate Form';

  @override
  String get generationFailed => 'Generation failed';

  @override
  String get pleaseTryAgain => 'Please try again';

  @override
  String get tryAgain => 'Try Again';

  @override
  String generatingYourForm(String formTitle) {
    return 'Generating your $formTitle...';
  }

  @override
  String get legalNotice => 'Legal Notice';

  @override
  String get privacyPolicyTitle => 'Privacy Policy';

  @override
  String get informationWeCollect => 'Information We Collect';

  @override
  String get howWeUseData => 'How We Use Data';

  @override
  String get thirdPartyServices => 'Third Party Services';

  @override
  String get aiProcessingNotice => 'AI Processing Notice';

  @override
  String get userRightsPolicy => 'User Rights';

  @override
  String get contactInformation => 'Contact Information';

  @override
  String get lastUpdated => 'Last updated: 2 June 2026';

  @override
  String get serviceUnavailable => 'Service unavailable';

  @override
  String get signInFeaturesTemporarilyUnavailable =>
      'Sign-in features are temporarily unavailable. Please try again later.';

  @override
  String get privacyPolicyBody =>
      'This page explains how JusLegal handles your information when you use the app for legal guidance.';

  @override
  String get appTagline => 'Know Your Rights. Take Action.';

  @override
  String get onboardingDisclaimer =>
      'JusLegal provides general legal guidance based on Indian law. It does not replace professional legal advice. For complex or criminal matters, always consult a practicing advocate.';

  @override
  String get resultDisclaimer => 'General guidance only. Not legal advice.';

  @override
  String get documentDisclaimer =>
      'This document was generated for reference purposes. Review carefully before sending.';

  @override
  String get problemSummaryEmpty => 'Problem summary cannot be empty.';

  @override
  String get serviceTemporarilyUnavailable =>
      'Service temporarily unavailable. Please try again in a few minutes.';

  @override
  String get noInternetConnection =>
      'No internet connection. Please check your network and try again.';

  @override
  String get tooManyRequests =>
      'Too many requests. Please wait a moment and try again.';

  @override
  String get networkError =>
      'Network error. Please check your connection and try again.';

  @override
  String get invalidCredentials => 'Invalid email or password.';

  @override
  String get userNotFound => 'No account was found with these details.';

  @override
  String get emailAlreadyInUse => 'An account already exists with this email.';

  @override
  String get weakPassword => 'Please choose a stronger password.';

  @override
  String get sessionExpired => 'Your session expired. Please sign in again.';

  @override
  String get invalidPhoneNumber => 'Please enter a valid phone number.';

  @override
  String get invalidOtp => 'The verification code is invalid.';

  @override
  String get otpFailed => 'OTP verification failed. Please try again.';

  @override
  String get configurationError =>
      'Service configuration error. Please try again later.';

  @override
  String get unableToProcessResponse =>
      'Unable to process AI response. Please try again.';
}
