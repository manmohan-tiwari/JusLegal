import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:juslegal/l10n/gen/app_localizations.dart';


import 'package:juslegal/core/core.dart';
import '../services/auth_handler.dart';
import '../providers/rate_us_provider.dart';
import '../widgets/empty_state_widget.dart';
import '../widgets/floating_ai_button.dart';
import '../widgets/hover_stay_reveal_box.dart';
import '../widgets/rate_us_sheet.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  static const SystemUiOverlayStyle _lightSurfaceOverlayStyle =
      SystemUiOverlayStyle(
    statusBarColor: AppColors.surface,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
  );
  int _tabIndex = 0;
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await ref.read(rateUsProvider.notifier).initAndIncrement();
      if (ref.read(rateUsProvider).shouldShowPrompt) {
        _showRateUsSheet();
      }
    });
  }

  void _showRateUsSheet() {
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const RateUsSheet(),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onTab(int index) {
    if (index == _tabIndex) {
      _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
    setState(() => _tabIndex = index);
    switch (index) {
      case 1:
        context.go('/home/cases');
        break;
      case 2:
        context.go('/home/authorities');
        break;
      case 3:
        context.go('/home/settings');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return LayoutBuilder(
      builder: (context, constraints) {
        final isDesktop = constraints.maxWidth > 600;
        final viewPadding = MediaQuery.paddingOf(context);
        final scrollPhysics =
            defaultTargetPlatform == TargetPlatform.android && !kIsWeb
                ? const BouncingScrollPhysics()
                : const ClampingScrollPhysics();
        const homeCategories = _HomeContent.popularCategories;
        final navItems = [
          _BottomNavItem(l10n.home, Icons.home_outlined, Icons.home_rounded),
          _BottomNavItem(
              l10n.myCases, Icons.folder_open_outlined, Icons.folder_rounded),
          _BottomNavItem(
              l10n.authorities, Icons.gavel_outlined, Icons.gavel_rounded),
          _BottomNavItem(
              l10n.settings, Icons.settings_outlined, Icons.settings_rounded),
        ];

        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: isDesktop
              ? _DesktopHeader(
                  selectedIndex: _tabIndex,
                  items: navItems,
                  onSelected: _onTab,
                )
              : AppBar(
                  toolbarHeight: 64,
                  titleSpacing: 16,
                  elevation: 0,
                  shadowColor: Colors.transparent,
                  backgroundColor: AppColors.warmOffWhite,
                  foregroundColor: AppColors.deepNavy,
                  surfaceTintColor: Colors.transparent,
                  centerTitle: false,
                  systemOverlayStyle: _lightSurfaceOverlayStyle,
                  bottom: const PreferredSize(
                    preferredSize: Size.fromHeight(1),
                    child: Divider(
                      height: 1,
                      thickness: 1,
                      color: AppColors.divider,
                    ),
                  ),
                  title: const Align(
                    alignment: Alignment.centerLeft,
                    child: _HeaderLogo(iconHeight: 40),
                  ),
                  actions: [
                    IconButton(
                      icon: const Icon(Icons.settings_outlined, color: AppColors.deepNavy),
                      onPressed: () => context.go('/home/settings'),
                      tooltip: l10n.settings,
                      constraints:
                          const BoxConstraints(minWidth: 48, minHeight: 48),
                    ),
                  ],
                ),
          body: SafeArea(
            top: false,
            child: SingleChildScrollView(
              controller: _scrollController,
              physics: scrollPhysics,
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: isDesktop ? 1200 : double.infinity,
                  ),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(
                      isDesktop ? 32 : 16,
                      isDesktop ? 28 : 16,
                      isDesktop ? 32 : 16,
                      isDesktop ? 36 : 132 + viewPadding.bottom,
                    ),
                    child: _HomeContent(
                      categories: homeCategories,
                      isDesktop: isDesktop,
                    ),
                  ),
                ),
              ),
            ),
          ),
          bottomNavigationBar: isDesktop
              ? null
              : _FloatingBottomNav(
                  selectedIndex: _tabIndex,
                  items: navItems,
                  onSelected: _onTab,
                ),
          floatingActionButton: Padding(
            padding: EdgeInsets.only(
              right: isDesktop ? 8 : 4,
              bottom: isDesktop ? 12 : 84 + viewPadding.bottom,
            ),
            child: _buildFloatingAIButton(),
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
        );
      },
    );
  }

  Widget _buildFloatingAIButton() {
    final authState = ref.watch(authProvider);
    final user = authState.user;
    final l10n = AppLocalizations.of(context);
    final name = user?.displayName?.split(' ').first ?? l10n.there;
    return FloatingAIButton(userName: name);
  }
}

// ---------------------------------------------
// AI Feature Tool model
// ---------------------------------------------

class _AiFeatureTool {
  final String title;
  final String description;
  final IconData icon;
  final String route;
  final String category; // 'chat' | 'documents'

  const _AiFeatureTool({
    required this.title,
    required this.description,
    required this.icon,
    required this.route,
    required this.category,
  });
}

// ---------------------------------------------
// Full feature list
// ---------------------------------------------

// ---------------------------------------------
// Home Content
// ---------------------------------------------

class _HomeContent extends StatelessWidget {
  final List<_PopularLegalCategory> categories;
  final bool isDesktop;

  static const popularCategories = <_PopularLegalCategory>[
    _PopularLegalCategory(
      title: 'Property & Rent',
      description: 'Rent agreements, eviction & security deposit theft',
      icon: Icons.home_work_outlined,
      categoryId: 'Housing & Real Estate',
    ),
    _PopularLegalCategory(
      title: 'Employment & Salary',
      description: 'Withheld salary, termination & workplace rights',
      icon: Icons.work_outline_rounded,
      categoryId: 'Employment',
    ),
    _PopularLegalCategory(
      title: 'Money Recovery & Cheque',
      description: 'Cheque bounce (Sec 138) & debt recovery notices',
      icon: Icons.account_balance_wallet_outlined,
      categoryId: 'Banking & UPI Fraud',
    ),
    _PopularLegalCategory(
      title: 'Cyber Crime & Bank Fraud',
      description: 'Account freeze, 1930 portal & online financial fraud',
      icon: Icons.shield_outlined,
      categoryId: 'Banking & UPI Fraud',
    ),
  ];

  const _HomeContent({
    required this.categories,
    required this.isDesktop,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final aiChatTools = [
      _AiFeatureTool(
        title: l10n.toolAiLawyerChatTitle,
        description: l10n.toolAiLawyerChatDesc,
        icon: Icons.chat_bubble_outline_rounded,
        route: '/home/ai-lawyer-chat',
        category: 'chat',
      ),
      _AiFeatureTool(
        title: l10n.toolLegalAdviceTitle,
        description: l10n.toolLegalAdviceDesc,
        icon: Icons.balance_outlined,
        route: '/home/legal-advice',
        category: 'chat',
      ),
      _AiFeatureTool(
        title: l10n.toolCaseAnalysisTitle,
        description: l10n.toolCaseAnalysisDesc,
        icon: Icons.track_changes_rounded,
        route: '/home/case-analysis',
        category: 'chat',
      ),
      _AiFeatureTool(
        title: l10n.toolLegalTermsTitle,
        description: l10n.toolLegalTermsDesc,
        icon: Icons.menu_book_outlined,
        route: '/home/legal-terms',
        category: 'chat',
      ),
    ];
    final documentTools = [
      _AiFeatureTool(
        title: l10n.toolLegalWritingTitle,
        description: l10n.toolLegalWritingDesc,
        icon: Icons.edit_note_rounded,
        route: '/home/legal-writing',
        category: 'documents',
      ),
      _AiFeatureTool(
        title: l10n.toolDocumentReviewTitle,
        description: l10n.toolDocumentReviewDesc,
        icon: Icons.fact_check_outlined,
        route: '/home/document-review',
        category: 'documents',
      ),
      _AiFeatureTool(
        title: 'Formal Notice & Complaint',
        description:
            'Draft formal legal notices with statutory consumer sections',
        icon: Icons.gavel_rounded,
        route: '/home/complaint',
        category: 'documents',
      ),
      _AiFeatureTool(
        title: l10n.authorities,
        description:
            'Direct access to Cybercrime, Consumer Helpline & RBI CMS',
        icon: Icons.account_balance_outlined,
        route: '/home/authorities',
        category: 'documents',
      ),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppAnimations.fadeSlideIn(
          _HeroSection(isDesktop: isDesktop),
          duration: const Duration(milliseconds: 300),
        ),
        const SizedBox(height: 24),

        // -- 3 Action Power Hubs ---------------------------
        _SectionLabel('CORE LEGAL HUBS'),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 11),
          child: Text(
            'Draft court documents, audit agreements, or resolve legal disputes with AI.',
            style: const TextStyle(
              color: Color(0xFF6B7280),
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ).copyWith(
              color: AppColors.textSecondary,
            ),
          ),
        ),
        const SizedBox(height: 14),
        _ThreeActionHubs(isDesktop: isDesktop),
        const SizedBox(height: 28),

        // -- High-Impact Legal Categories ------------------
        _SectionLabel(l10n.exploreLegalCategories),
        const SizedBox(height: 16),
        if (categories.isEmpty)
          const EmptyStateWidget(
            icon: Icons.category_outlined,
            title: 'No categories available',
            subtitle: 'Please check back later for legal topics.',
          )
        else
          LayoutBuilder(
            builder: (context, constraints) {
              final columns =
                  isDesktop ? 4 : (constraints.maxWidth < 360 ? 1 : 2);
              final spacing = isDesktop ? 14.0 : 12.0;
              final itemWidth =
                  (constraints.maxWidth - (spacing * (columns - 1))) / columns;

              return Wrap(
                spacing: spacing,
                runSpacing: spacing,
                children: List.generate(categories.length, (index) {
                  return SizedBox(
                    width: itemWidth,
                    child: AppAnimations.staggeredListItem(
                      _CategoryCard(
                        category: categories[index],
                        onTap: () => context.go(
                          '/home/analyzer?category=${Uri.encodeComponent(categories[index].categoryId)}',
                        ),
                      ),
                      index,
                    ),
                  );
                }),
              );
            },
          ),
        const SizedBox(height: 16),
        Center(
          child: TextButton(
            onPressed: () => context.go('/home/analyzer'),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(l10n.showAllCategories),
                const SizedBox(width: 4),
                const Icon(Icons.arrow_forward_rounded, size: 18),
              ],
            ),
          ),
        ),

        // -- AI Chat & Analysis Tools ----------------------
        SizedBox(height: isDesktop ? 32 : 28),
        _SectionLabel(l10n.aiChatLegalQueriesAndAnalysis),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 11),
          child: Text(
            l10n.instantAIPoweredLegalGuidanceAtYourFingertips,
            style: const TextStyle(
              color: Color(0xFF6B7280),
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ).copyWith(
              color: AppColors.textSecondary,
            ),
          ),
        ),
        const SizedBox(height: 14),
        AppAnimations.fadeSlideIn(
          _AiToolsGrid(tools: aiChatTools, isDesktop: isDesktop),
          delay: const Duration(milliseconds: 50),
        ),

        // -- Documents & Contracts Tools -------------------
        SizedBox(height: isDesktop ? 32 : 28),
        _SectionLabel(l10n.documentsAndContracts),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 11),
          child: Text(
            l10n.generateReviewAndNegotiateLegalDocumentsWithAI,
            style: const TextStyle(
              color: Color(0xFF6B7280),
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ).copyWith(
              color: AppColors.textSecondary,
            ),
          ),
        ),
        const SizedBox(height: 14),
        AppAnimations.fadeSlideIn(
          _AiToolsGrid(tools: documentTools, isDesktop: isDesktop),
          delay: const Duration(milliseconds: 90),
        ),

      ],
    );
  }
}

// ---------------------------------------------
// AI Tools Grid
// ---------------------------------------------

class _AiToolsGrid extends StatelessWidget {
  final List<_AiFeatureTool> tools;
  final bool isDesktop;

  const _AiToolsGrid({required this.tools, required this.isDesktop});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = isDesktop ? 4 : (constraints.maxWidth < 360 ? 1 : 2);
        const spacing = 12.0;
        final itemWidth =
            (constraints.maxWidth - (spacing * (columns - 1))) / columns;

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: List.generate(tools.length, (index) {
            return SizedBox(
              width: itemWidth,
              child: AppAnimations.staggeredListItem(
                _AiToolCard(
                  tool: tools[index],
                  onTap: () => context.push(tools[index].route),
                ),
                index,
              ),
            );
          }),
        );
      },
    );
  }
}

// ---------------------------------------------
// AI Tool Card
// ---------------------------------------------

class _AiToolCard extends StatelessWidget {
  final _AiFeatureTool tool;
  final VoidCallback onTap;

  const _AiToolCard({required this.tool, required this.onTap});

  Color get _accentColor =>
      tool.category == 'documents' ? AppColors.mustardGold : AppColors.slateBlue;

  Color get _iconBg => tool.category == 'documents'
      ? AppColors.paleYellow
      : AppColors.paleBlue;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(18);
    return HoverStayRevealBox(
      onTap: onTap,
      borderRadius: radius,
      builder: (context, isRevealed) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surfaceContainerLowest,
            borderRadius: radius,
            border: Border.all(
              color: isRevealed
                  ? _accentColor.withValues(alpha: 0.5)
                  : AppColors.border,
              width: isRevealed ? 1.5 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: isRevealed
                    ? _accentColor.withValues(alpha: 0.14)
                    : const Color(0x0A162B49),
                blurRadius: isRevealed ? 14 : 10,
                offset: Offset(0, isRevealed ? 5 : 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon circle
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: _iconBg,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  tool.icon,
                  color: _accentColor,
                  size: 24,
                ),
              ),
              const SizedBox(height: 12),

              // Title
              Text(
                tool.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w800,
                    ),
              ),

              // Description (revealed on hover or mobile stay)
              HoverRevealContent(
                isRevealed: isRevealed,
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  tool.description,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                        height: 1.35,
                      ),
                ),
              ),

              // Bottom arrow chip
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Open',
                        style: TextStyle(
                          color: _accentColor,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(width: 2),
                      AnimatedSlide(
                        duration: const Duration(milliseconds: 180),
                        offset: isRevealed ? const Offset(0.25, 0) : Offset.zero,
                        child: Icon(
                          Icons.arrow_forward_rounded,
                          size: 12,
                          color: _accentColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------------------------------
// Existing widgets below - unchanged
// ---------------------------------------------

class _HeroSection extends StatelessWidget {
  final bool isDesktop;

  const _HeroSection({required this.isDesktop});

  @override
  Widget build(BuildContext context) {
    final horizontalPadding = isDesktop ? 48.0 : 24.0;
    final verticalPadding = isDesktop ? 44.0 : 30.0;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: horizontalPadding,
        vertical: verticalPadding,
      ),
      decoration: BoxDecoration(
        color: AppColors.deepNavy,
        borderRadius: BorderRadius.circular(AppTheme.radiusL),
        boxShadow: const [
          BoxShadow(
            color: AppColors.shadowStrong,
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: isDesktop
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  flex: 6,
                  child: _HeroContent(isDesktop: true),
                ),
                const SizedBox(width: 32),
                Expanded(
                  flex: 4,
                  child: _LegalOfficeIllustration(height: 248),
                ),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _HeroContent(isDesktop: false),
                SizedBox(height: 24),
                _LegalOfficeIllustration(height: 156),
              ],
            ),
    );
  }
}

class _HeroContent extends StatelessWidget {
  final bool isDesktop;

  const _HeroContent({required this.isDesktop});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    final compactMobile = !isDesktop && screenWidth <= 360;
    final headlineStyle = GoogleFonts.plusJakartaSans(
      color: Colors.white,
      fontSize: isDesktop ? 38 : (compactMobile ? 26 : 30),
      fontWeight: FontWeight.w800,
      height: 1.2,
      letterSpacing: -0.01,
    );
    final bodyStyle = GoogleFonts.plusJakartaSans(
      color: AppColors.paleBlue,
      fontSize: compactMobile ? 13 : 14,
      fontWeight: FontWeight.w400,
      height: 1.5,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'Navigate Indian Law\nwith Confidence',
          style: headlineStyle,
        ),
        SizedBox(height: compactMobile ? 10 : 12),
        Text(
          'Clear, AI-powered legal guidance and practical next steps for the moments that matter.',
          style: bodyStyle,
        ),
        SizedBox(height: compactMobile ? 18 : 20),
        SizedBox(
          width: isDesktop ? 220 : double.infinity,
          child: ElevatedButton(
            onPressed: () => context.go('/home/analyzer'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.mustardGold,
              foregroundColor: AppColors.deepNavy,
              elevation: 0,
              minimumSize: const Size.fromHeight(50),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppTheme.radiusM),
              ),
              textStyle: GoogleFonts.plusJakartaSans(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            child: const Text('Get Started'),
          ),
        ),
      ],
    );
  }
}

/// A code-native legal office illustration so the hero remains sharp on web,
/// mobile, and high-density screens without loading a bitmap at runtime.
class _LegalOfficeIllustration extends StatelessWidget {
  final double height;

  const _LegalOfficeIllustration({required this.height});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _LegalOfficePainter(),
      ),
    );
  }
}

class _LegalOfficePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final darkNavy = Paint()..color = const Color(0xFF0F1E33);
    const gold = AppColors.mustardGold;
    final glass = Paint()..color = Colors.white.withValues(alpha: 0.12);
    final light = Paint()..color = Colors.white.withValues(alpha: 0.85);
    final accentBlue = Paint()..color = AppColors.navyBlue;

    canvas.drawRRect(
        RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(8)),
        glass);
    // Window grid and warm office desk.
    final window = Rect.fromLTWH(size.width * .12, size.height * .08,
        size.width * .76, size.height * .54);
    canvas.drawRRect(
        RRect.fromRectAndRadius(window, const Radius.circular(6)), darkNavy);
    for (var x = window.left + window.width / 3;
        x < window.right;
        x += window.width / 3) {
      canvas.drawRect(Rect.fromLTWH(x, window.top, 2, window.height), glass);
    }
    canvas.drawRect(
        Rect.fromLTWH(
            window.left, window.top + window.height * .52, window.width, 2),
        glass);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(size.width * .08, size.height * .72, size.width * .84,
                size.height * .12),
            const Radius.circular(4)),
        light);
    canvas.drawRect(
        Rect.fromLTWH(
            size.width * .19, size.height * .82, 8, size.height * .13),
        darkNavy);
    canvas.drawRect(
        Rect.fromLTWH(
            size.width * .79, size.height * .82, 8, size.height * .13),
        darkNavy);
    // Justice scales on the desk in Mustard Gold.
    final center = Offset(size.width * .50, size.height * .64);
    final stroke = Paint()
      ..color = gold
      ..strokeWidth = 3.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
        center, Offset(center.dx, center.dy + size.height * .12), stroke);
    canvas.drawLine(Offset(center.dx - size.width * .19, center.dy),
        Offset(center.dx + size.width * .19, center.dy), stroke);
    canvas.drawLine(
        Offset(center.dx - size.width * .13, center.dy),
        Offset(center.dx - size.width * .18, center.dy + size.height * .10),
        stroke);
    canvas.drawLine(
        Offset(center.dx + size.width * .13, center.dy),
        Offset(center.dx + size.width * .18, center.dy + size.height * .10),
        stroke);
    canvas.drawArc(
        Rect.fromCenter(
            center: Offset(
                center.dx - size.width * .18, center.dy + size.height * .10),
            width: size.width * .16,
            height: size.height * .08),
        0,
        3.14,
        false,
        stroke);
    canvas.drawArc(
        Rect.fromCenter(
            center: Offset(
                center.dx + size.width * .18, center.dy + size.height * .10),
            width: size.width * .16,
            height: size.height * .08),
        0,
        3.14,
        false,
        stroke);
    // Blue accent details
    for (final offset in [
      Offset(size.width * .09, size.height * .67),
      Offset(size.width * .14, size.height * .60),
      Offset(size.width * .05, size.height * .58)
    ]) {
      canvas.drawOval(
          Rect.fromCenter(
              center: offset,
              width: size.width * .12,
              height: size.height * .06),
          accentBlue);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _CategoryCard extends StatelessWidget {
  final _PopularLegalCategory category;
  final VoidCallback onTap;

  const _CategoryCard({
    required this.category,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(AppTheme.radiusL);
    return AppAnimations.pressScale(
      onTap: onTap,
      borderRadius: radius,
      splashColor: AppColors.navyBlue.withValues(alpha: 0.1),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surfaceContainerLowest,
          borderRadius: radius,
          border: Border.all(color: AppColors.outline),
          boxShadow: const [
            BoxShadow(
              color: AppColors.shadow,
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: AppColors.paleBlue,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                category.icon,
                color: AppColors.deepNavy,
                size: 26,
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Text(
                category.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.deepNavy,
                  fontWeight: FontWeight.w700,
                  fontSize: 14.5,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              category.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.navyBlue,
                fontSize: 12.5,
                height: 1.35,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PopularLegalCategory {
  final String title;
  final String description;
  final IconData icon;
  final String categoryId;

  const _PopularLegalCategory({
    required this.title,
    required this.description,
    required this.icon,
    required this.categoryId,
  });

  String get name => title;
}

class _SectionLabel extends StatelessWidget {
  final String title;

  const _SectionLabel(this.title);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: AppColors.mustardGold,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title.toUpperCase(),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.deepNavy,
              fontSize: 13,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
            ),
          ),
        ),
      ],
    );
  }
}

class _DesktopHeader extends StatelessWidget implements PreferredSizeWidget {
  final int selectedIndex;
  final List<_BottomNavItem> items;
  final ValueChanged<int> onSelected;

  const _DesktopHeader({
    required this.selectedIndex,
    required this.items,
    required this.onSelected,
  });

  @override
  Size get preferredSize => const Size.fromHeight(72);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      systemOverlayStyle: _HomeScreenState._lightSurfaceOverlayStyle,
      toolbarHeight: preferredSize.height,
      titleSpacing: 24,
      backgroundColor: AppColors.warmOffWhite,
      scrolledUnderElevation: 0,
      elevation: 0,
      bottom: const PreferredSize(
        preferredSize: Size.fromHeight(1),
        child: Divider(height: 1, thickness: 1, color: AppColors.divider),
      ),
      title: const Align(
        alignment: Alignment.centerLeft,
        child: _HeaderLogo(iconHeight: 44),
      ),
      actions: [
        ...List.generate(items.length, (index) {
          final selected = selectedIndex == index;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: TextButton.icon(
              onPressed: () => onSelected(index),
              icon: Icon(
                selected ? items[index].selectedIcon : items[index].icon,
                size: 18,
                color: selected ? AppColors.deepNavy : AppColors.navyBlue,
              ),
              label: Text(
                items[index].label,
                style: TextStyle(
                  color: selected ? AppColors.deepNavy : AppColors.navyBlue,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor:
                    selected ? AppColors.mustardGold : Colors.transparent,
                minimumSize: const Size(48, 44),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppTheme.radiusM),
                ),
              ),
            ),
          );
        }),
        const SizedBox(width: 20),
      ],
    );
  }
}

class _HeaderLogo extends StatelessWidget {
  final double iconHeight;

  const _HeaderLogo({required this.iconHeight});

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/images/logo.png',
      height: iconHeight,
      fit: BoxFit.contain,
    );
  }
}

class _FloatingBottomNav extends StatelessWidget {
  final int selectedIndex;
  final List<_BottomNavItem> items;
  final ValueChanged<int> onSelected;

  const _FloatingBottomNav({
    required this.selectedIndex,
    required this.items,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppTheme.radiusXL),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.deepNavy,
              borderRadius: BorderRadius.circular(AppTheme.radiusXL),
              border: Border.all(color: const Color(0x26FAF8F2)),
              boxShadow: const [
                BoxShadow(
                  color: AppColors.shadowStrong,
                  blurRadius: 24,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              children: List.generate(items.length, (index) {
                final item = items[index];
                final selected = index == selectedIndex;

                return Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(AppTheme.radiusM),
                    onTap: () => onSelected(index),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      constraints: const BoxConstraints(minHeight: 48),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: selected
                            ? AppColors.mustardGold
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(AppTheme.radiusM),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            selected ? item.selectedIcon : item.icon,
                            color: selected
                                ? AppColors.deepNavy
                                : AppColors.paleBlue,
                            size: 22,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            item.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: selected
                                  ? AppColors.deepNavy
                                  : AppColors.paleBlue,
                              fontSize: 11,
                              fontWeight:
                                  selected ? FontWeight.w700 : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _BottomNavItem {
  final String label;
  final IconData icon;
  final IconData selectedIcon;

  const _BottomNavItem(this.label, this.icon, this.selectedIcon);
}

// ---------------------------------------------
// 3 Core Action Power Hubs (Pastel Cards Matching Screenshot 1)
// ---------------------------------------------

class _ThreeActionHubs extends StatelessWidget {
  final bool isDesktop;

  const _ThreeActionHubs({required this.isDesktop});

  @override
  Widget build(BuildContext context) {
    final hubs = [
      _HubData(
        tag: '30+ COURT TEMPLATES',
        title: 'Draft Legal Documents',
        subtitle:
            'Rent Agreements, 15-Day Legal Demand Notices, Cheque Bounce, Affidavits & RTIs with instant PDF download.',
        icon: Icons.edit_document,
        buttonText: 'Create Document',
        backgroundColor: AppColors.paleBlue,
        badgeBgColor: AppColors.surfaceContainerLowest,
        badgeTextColor: AppColors.deepNavy,
        onTap: () => context.push('/home/legal-writing'),
      ),
      _HubData(
        tag: 'AI CONTRACT AUDITOR',
        title: 'Audit & Review Contracts',
        subtitle:
            'Scan leases, offer letters & NDAs before signing. Detect one-sided clauses, lock-in penalties & get a Safety Score.',
        icon: Icons.fact_check_outlined,
        buttonText: 'Audit Document',
        backgroundColor: AppColors.paleYellow,
        badgeBgColor: AppColors.surfaceContainerLowest,
        badgeTextColor: AppColors.deepNavy,
        onTap: () => context.push('/home/document-review'),
      ),
      _HubData(
        tag: 'INSTANT LEGAL RESOLUTION',
        title: 'Resolve Legal Disputes',
        subtitle:
            'Withheld salary, security deposit theft, money recovery, or cyber fraud — get exact Indian laws & action plans.',
        icon: Icons.gavel_rounded,
        buttonText: 'Solve Dispute',
        backgroundColor: AppColors.paleGreen,
        badgeBgColor: AppColors.surfaceContainerLowest,
        badgeTextColor: AppColors.deepNavy,
        onTap: () => context.go('/home/analyzer'),
      ),
    ];

    if (isDesktop) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: hubs
            .map((hub) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: _HubCard(data: hub),
                  ),
                ))
            .toList(),
      );
    }

    return Column(
      children: hubs
          .map((hub) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _HubCard(data: hub),
              ))
          .toList(),
    );
  }
}

class _HubData {
  final String tag;
  final String title;
  final String subtitle;
  final IconData icon;
  final String buttonText;
  final Color backgroundColor;
  final Color badgeBgColor;
  final Color badgeTextColor;
  final VoidCallback onTap;

  const _HubData({
    required this.tag,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.buttonText,
    required this.backgroundColor,
    required this.badgeBgColor,
    required this.badgeTextColor,
    required this.onTap,
  });
}

class _HubCard extends StatelessWidget {
  final _HubData data;

  const _HubCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(AppTheme.radiusL);
    return HoverStayRevealBox(
      onTap: data.onTap,
      borderRadius: radius,
      builder: (context, isRevealed) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: double.infinity,
          decoration: BoxDecoration(
            color: data.backgroundColor,
            borderRadius: radius,
            border: Border.all(
              color: isRevealed
                  ? AppColors.deepNavy.withValues(alpha: 0.35)
                  : AppColors.outline,
              width: isRevealed ? 1.5 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: isRevealed
                    ? AppColors.deepNavy.withValues(alpha: 0.12)
                    : AppColors.shadow,
                blurRadius: isRevealed ? 16 : 10,
                offset: Offset(0, isRevealed ? 5 : 3),
              ),
            ],
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top row: Tag badge & Icon badge
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: data.badgeBgColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppColors.outline,
                        width: 1,
                      ),
                    ),
                    child: Text(
                      data.tag,
                      style: TextStyle(
                        color: data.badgeTextColor,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isRevealed
                          ? AppColors.mustardGold.withValues(alpha: 0.3)
                          : AppColors.surfaceContainerLowest,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      data.icon,
                      color: AppColors.deepNavy,
                      size: 20,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // Title
              Text(
                data.title,
                style: const TextStyle(
                  color: AppColors.deepNavy,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),

              // Subtitle (revealed on hover or mobile stay)
              HoverRevealContent(
                isRevealed: isRevealed,
                padding: const EdgeInsets.only(top: 8, bottom: 2),
                child: Text(
                  data.subtitle,
                  style: const TextStyle(
                    color: AppColors.navyBlue,
                    fontSize: 13,
                    height: 1.45,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // Action pill
              Row(
                children: [
                  Text(
                    data.buttonText,
                    style: const TextStyle(
                      color: AppColors.deepNavy,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(width: 4),
                  AnimatedSlide(
                    duration: const Duration(milliseconds: 200),
                    offset: isRevealed ? const Offset(0.25, 0) : Offset.zero,
                    child: const Icon(
                      Icons.arrow_forward_rounded,
                      size: 16,
                      color: AppColors.mustardGold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

