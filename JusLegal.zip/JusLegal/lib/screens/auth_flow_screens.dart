import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:juslegal/core/core.dart';
import 'package:juslegal/core/router/otp_route_params.dart';
import 'package:juslegal/core/utils/phone_number_validator.dart';
import 'package:juslegal/services/auth_handler.dart';
import 'package:juslegal/services/user_profile_service.dart';

String? legalNameError(String? value) =>
    RegExp(r"^[A-Za-z][A-Za-z '\-]{1,98}$").hasMatch(value?.trim() ?? '')
        ? null
        : 'Please enter a valid legal name';

class AuthScaffold extends StatelessWidget {
  const AuthScaffold({super.key, required this.child, this.showBack = true});
  final Widget child;
  final bool showBack;
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.warmOffWhite,
        appBar: showBack
            ? AppBar(
                backgroundColor: AppColors.warmOffWhite,
                foregroundColor: AppColors.deepNavy,
                iconTheme: const IconThemeData(color: AppColors.deepNavy),
                elevation: 0,
              )
            : null,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: child,
              ),
            ),
          ),
        ),
      );
}

class WelcomeScreen extends ConsumerStatefulWidget {
  const WelcomeScreen({super.key});

  @override
  ConsumerState<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends ConsumerState<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  // Design tokens (8px grid)
  static const Color _ink = Color(0xFF17294A);
  static const Color _paper = Color(0xFFF9F7F2);
  static const Color _accent = Color(0xFFF5B82E);
  static const Color _moss = Color(0xFF6CC47A);
  static const Color _muted = Color(0xFF3D6A96);
  static const double _radiusField = 12.0;
  static const double _radiusBtn = 14.0;

  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  late final AnimationController _entrance;
  late final Animation<double> _fadeAnimation;
  late final Animation<Offset> _slideAnimation;
  bool _hasStartedAnimation = false;
  bool _acceptedTerms = false;
  bool _hidePassword = true;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _entrance = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _entrance,
      curve: Curves.easeOut,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.04),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entrance,
      curve: Curves.easeOut,
    ));
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_hasStartedAnimation) {
      _hasStartedAnimation = true;
      // Wrap all animation to disable under prefers-reduced-motion
      final prefersReducedMotion =
          MediaQuery.maybeOf(context)?.disableAnimations ?? false;
      if (prefersReducedMotion) {
        _entrance.value = 1.0;
      } else {
        _entrance.forward();
      }
    }
  }

  @override
  void dispose() {
    _entrance.dispose();
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (!_acceptedTerms) {
      _snack(context, 'Please accept the Terms of Service to continue.');
      return;
    }
    setState(() => _loading = true);
    try {
      final email = _email.text.trim().toLowerCase();
      if (await UserProfileService().emailExists(email)) {
        throw Exception(
            'This email is already registered. Try logging in instead.');
      }
      final credential =
          await ref.read(authProvider.notifier).registerWithEmail(
                email,
                _password.text,
              );
      await UserProfileService().saveProfile(
        credential.user!,
        legalName: _name.text.trim(),
        provider: 'email',
      );
      if (mounted) context.go('/email-verification', extra: email);
    } catch (error) {
      if (mounted) _snack(context, friendlyError(error));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: _paper,
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final isWide = constraints.maxWidth >= 900;
              if (isWide) {
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 10,
                      child: _visualPanelDesktop(),
                    ),
                    Expanded(
                      flex: 11,
                      child: Center(
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 48,
                            vertical: 32,
                          ),
                          child: _animatedForm(isWide: true),
                        ),
                      ),
                    ),
                  ],
                );
              }

              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _visualPanelMobile(),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: constraints.maxWidth < 400 ? 16 : 24,
                          vertical: 24,
                        ),
                        child: _animatedForm(isWide: false),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      );

  Widget _visualPanelDesktop() => Container(
        color: _ink,
        padding: const EdgeInsets.all(48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Logo moved to top-left, aligned with panel left margin
            Image.asset(
              'assets/images/logo.png',
              height: 48,
              fit: BoxFit.contain,
              alignment: Alignment.centerLeft,
            ),
            // Pin copy to lower third
            const Spacer(flex: 3),
            Text(
              'Expert Legal Guidance',
              style: GoogleFonts.plusJakartaSans(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.01,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Instant clarity on Indian laws, rights, and remedies.',
              style: GoogleFonts.plusJakartaSans(
                color: Colors.white.withValues(alpha: 0.8),
                fontSize: 14,
                height: 1.45,
              ),
            ),
            const SizedBox(height: 24),
            // Realistic sample card with plain-language legal question, answer, and editable citation placeholder
            _buildSampleCard(),
            const Spacer(flex: 1),
          ],
        ),
      );

  Widget _visualPanelMobile() => Container(
        color: _ink,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(
          children: [
            Image.asset(
              'assets/images/logo.png',
              height: 32,
              fit: BoxFit.contain,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Instant clarity on Indian laws, rights, and remedies.',
                style: GoogleFonts.plusJakartaSans(
                  color: Colors.white.withValues(alpha: 0.88),
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  height: 1.3,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      );

  Widget _buildSampleCard() => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.07),
          borderRadius: BorderRadius.circular(_radiusField),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.12),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _moss.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'Q',
                    style: GoogleFonts.plusJakartaSans(
                      color: _moss,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Can my landlord cut the power?',
                    style: GoogleFonts.plusJakartaSans(
                      color: Colors.white,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.only(left: 24),
              child: Text(
                'A: No. Electricity is an essential service; cutting it without due process is unlawful.\n— cite: Model Tenancy Act / Relevant State Rent Control Act, Sec. 20',
                style: GoogleFonts.plusJakartaSans(
                  color: Colors.white.withValues(alpha: 0.82),
                  fontSize: 12.5,
                  height: 1.45,
                ),
              ),
            ),
          ],
        ),
      );

  Widget _animatedForm({required bool isWide}) => AnimatedBuilder(
        animation: _entrance,
        builder: (context, child) => FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: child,
          ),
        ),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: _formContent(),
        ),
      );

  Widget _formContent() => Form(
        key: _form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Refined serif headline without all-caps, eyebrows, or single-word accents
            Text(
              'Get Legal Clarity',
              style: GoogleFonts.fraunces(
                fontSize: 40,
                fontWeight: FontWeight.w600,
                letterSpacing: -0.4,
                color: _ink,
                height: 1.15,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Sign up to start exploring your rights',
              style: GoogleFonts.plusJakartaSans(
                color: _muted,
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 32),

            // Visible label above Full name
            _buildFieldLabel('Full name'),
            const SizedBox(height: 8),
            _buildTextInput(
              controller: _name,
              hint: 'Enter your full legal name',
              icon: Icons.person_outline,
              validator: legalNameError,
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 16),

            // Visible label above Email address
            _buildFieldLabel('Email address'),
            const SizedBox(height: 8),
            _buildTextInput(
              controller: _email,
              hint: 'name@example.com',
              icon: Icons.mail_outline,
              keyboard: TextInputType.emailAddress,
              validator: (value) => EmailValidator.isValid(value?.trim() ?? '')
                  ? null
                  : 'Enter a valid email address',
            ),
            const SizedBox(height: 16),

            // Visible label above Password
            _buildFieldLabel('Password'),
            const SizedBox(height: 8),
            _buildTextInput(
              controller: _password,
              hint: 'At least 8 characters',
              icon: Icons.lock_outline,
              obscure: _hidePassword,
              suffix: Semantics(
                label: _hidePassword ? 'Show password' : 'Hide password',
                button: true,
                toggled: !_hidePassword,
                child: IconButton(
                  tooltip: _hidePassword ? 'Show password' : 'Hide password',
                  icon: Icon(
                    _hidePassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 20,
                    color: _muted,
                  ),
                  onPressed: () =>
                      setState(() => _hidePassword = !_hidePassword),
                ),
              ),
              validator: (value) => PasswordValidator.isStrong(value ?? '')
                  ? null
                  : 'Use 8+ characters with upper, lower, number, and symbol',
            ),
            const SizedBox(height: 16),

            // Terms checkbox with label association, smaller text, underlined link, and navy text
            InkWell(
              onTap: () => setState(() => _acceptedTerms = !_acceptedTerms),
              borderRadius: BorderRadius.circular(6),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 22,
                      height: 22,
                      child: Checkbox(
                        value: _acceptedTerms,
                        onChanged: (value) =>
                            setState(() => _acceptedTerms = value ?? false),
                        activeColor: _accent,
                        checkColor: _ink,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        side: const BorderSide(color: _muted, width: 1.5),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text.rich(
                        TextSpan(
                          text: 'I agree to the ',
                          style: GoogleFonts.plusJakartaSans(
                            color: _ink,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                          children: [
                            TextSpan(
                              text: 'Terms of Service',
                              style: GoogleFonts.plusJakartaSans(
                                color: _ink,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Primary "Create account" button: only amber element, full width, --radius-btn, navy text
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _loading ? null : _submit,
                style: ButtonStyle(
                  backgroundColor: WidgetStateProperty.resolveWith((states) {
                    if (states.contains(WidgetState.disabled)) {
                      return _accent.withValues(alpha: 0.55);
                    }
                    if (states.contains(WidgetState.hovered)) {
                      return const Color(0xFFE5A822); // subtle darken on hover
                    }
                    return _accent;
                  }),
                  foregroundColor: WidgetStateProperty.all(_ink),
                  elevation: WidgetStateProperty.all(0),
                  shape: WidgetStateProperty.resolveWith((states) {
                    final side = states.contains(WidgetState.focused)
                        ? const BorderSide(color: _ink, width: 2)
                        : BorderSide.none;
                    return RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(_radiusBtn),
                      side: side,
                    );
                  }),
                ),
                child: _loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _ink,
                        ),
                      )
                    : Text(
                        'Create account',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: _ink,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 16),

            // Secondary text-style button with no arrow icon
            Center(
              child: TextButton(
                onPressed: () => context.go('/home'),
                style: TextButton.styleFrom(
                  foregroundColor: _ink,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                child: Text(
                  'Explore App as Guest',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: _ink,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // "Already have an account? Log in" with hover underline on link
            Center(
              child: Wrap(
                alignment: WrapAlignment.center,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    'Already have an account? ',
                    style: GoogleFonts.plusJakartaSans(
                      color: _muted,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  _HoverLink(
                    text: 'Log in',
                    onTap: () => context.push('/login'),
                    style: GoogleFonts.plusJakartaSans(
                      color: _ink,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _buildFieldLabel(String label) => Text(
        label,
        style: GoogleFonts.plusJakartaSans(
          color: _ink,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      );

  Widget _buildTextInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboard,
    TextCapitalization textCapitalization = TextCapitalization.none,
    String? Function(String?)? validator,
  }) =>
      TextFormField(
        controller: controller,
        obscureText: obscure,
        keyboardType: keyboard,
        textCapitalization: textCapitalization,
        validator: validator,
        style: GoogleFonts.plusJakartaSans(
          color: _ink,
          fontSize: 15,
          fontWeight: FontWeight.w500,
        ),
        cursorColor: _ink,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: GoogleFonts.plusJakartaSans(
            color: _muted.withValues(alpha: 0.65),
            fontSize: 14,
          ),
          filled: true,
          fillColor: Colors.white,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          prefixIcon: Icon(
            icon,
            size: 20,
            color: _muted,
          ),
          suffixIcon: suffix,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_radiusField),
            borderSide: const BorderSide(color: Color(0xFFD4E2EC), width: 1.0),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_radiusField),
            borderSide: const BorderSide(color: Color(0xFFD4E2EC), width: 1.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_radiusField),
            borderSide: const BorderSide(color: _ink, width: 2.0),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_radiusField),
            borderSide: const BorderSide(color: Color(0xFFC62828), width: 1.0),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_radiusField),
            borderSide: const BorderSide(color: Color(0xFFC62828), width: 2.0),
          ),
        ),
      );
}

class _HoverLink extends StatefulWidget {
  final String text;
  final VoidCallback onTap;
  final TextStyle style;

  const _HoverLink({
    required this.text,
    required this.onTap,
    required this.style,
  });

  @override
  State<_HoverLink> createState() => _HoverLinkState();
}

class _HoverLinkState extends State<_HoverLink> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      child: Builder(
        builder: (context) {
          final isFocused = Focus.of(context).hasFocus;
          return MouseRegion(
            cursor: SystemMouseCursors.click,
            onEnter: (_) => setState(() => _isHovered = true),
            onExit: (_) => setState(() => _isHovered = false),
            child: GestureDetector(
              onTap: widget.onTap,
              child: Container(
                decoration: BoxDecoration(
                  border: isFocused
                      ? Border.all(color: const Color(0xFF17294A), width: 1.5)
                      : null,
                  borderRadius: BorderRadius.circular(4),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
                child: Text(
                  widget.text,
                  style: widget.style.copyWith(
                    decoration: (_isHovered || isFocused)
                        ? TextDecoration.underline
                        : TextDecoration.none,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}



class SignUpMethodScreen extends ConsumerWidget {
  const SignUpMethodScreen({super.key});
  Future<void> _google(BuildContext context, WidgetRef ref) async {
    try {
      final credential =
          await ref.read(authProvider.notifier).signInWithGoogle();
      final user = credential.user!;
      final profile = UserProfileService();
      if (!await profile.exists(user.uid)) {
        final name = user.displayName?.trim() ?? '';
        if (legalNameError(name) != null) {
          if (context.mounted) context.push('/confirm-name', extra: user);
          return;
        }
        await profile.saveProfile(user, legalName: name, provider: 'google');
      }
      if (context.mounted) context.go('/home');
    } catch (e) {
      if (context.mounted) _snack(context, friendlyError(e));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) => AuthScaffold(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('Create an account',
            style: Theme.of(context)
                .textTheme
                .headlineMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Choose how you would like to continue.'),
        const SizedBox(height: 32),
        OutlinedButton.icon(
            onPressed: () => _google(context, ref),
            icon: const Icon(Icons.g_mobiledata, size: 28),
            label: const Text('Continue with Google')),
        const SizedBox(height: 12),
        OutlinedButton.icon(
            onPressed: () => context.push('/mobile-signup'),
            icon: const Icon(Icons.phone_outlined),
            label: const Text('Continue with Mobile')),
        const SizedBox(height: 12),
        OutlinedButton.icon(
            onPressed: () => context.push('/email-signup'),
            icon: const Icon(Icons.email_outlined),
            label: const Text('Continue with Email')),
      ]));
}

class EmailSignupScreen extends ConsumerStatefulWidget {
  const EmailSignupScreen({super.key});
  @override
  ConsumerState<EmailSignupScreen> createState() => _EmailSignupScreenState();
}

class _EmailSignupScreenState extends ConsumerState<EmailSignupScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _hide = true;
  bool _loading = false;
  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final email = _email.text.trim().toLowerCase();
      if (await UserProfileService().emailExists(email)) {
        throw Exception(
            'This email is already registered. Try logging in instead.');
      }
      final credential = await ref
          .read(authProvider.notifier)
          .registerWithEmail(email, _password.text);
      await UserProfileService().saveProfile(credential.user!,
          legalName: _name.text, provider: 'email');
      if (mounted) context.go('/email-verification', extra: email);
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthScaffold(
      child: Form(
          key: _form,
          onChanged: () => setState(() {}),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Create Your Account',
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 28),
            _field(_name, 'Legal Name', 'Enter your full legal name',
                validator: legalNameError,
                textCapitalization: TextCapitalization.words),
            const SizedBox(height: 14),
            _field(_email, 'Email Address', 'name@example.com',
                keyboard: TextInputType.emailAddress,
                validator: (v) => EmailValidator.isValid(v?.trim() ?? '')
                    ? null
                    : 'Please enter a valid email address'),
            const SizedBox(height: 14),
            _field(_password, 'Password', 'Create a strong password',
                obscure: _hide,
                suffix: IconButton(
                    icon: Icon(_hide
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                    onPressed: () => setState(() => _hide = !_hide)),
                validator: (v) => PasswordValidator.isStrong(v ?? '')
                    ? null
                    : 'Password must be 8+ chars with uppercase, lowercase, number, and special character'),
            const SizedBox(height: 14),
            _field(_confirm, 'Confirm Password', 'Re-enter your password',
                obscure: _hide,
                validator: (v) =>
                    v == _password.text ? null : 'Passwords do not match'),
            const SizedBox(height: 26),
            SizedBox(
                height: 52,
                child: ElevatedButton(
                    onPressed: _loading ? null : _submit,
                    child: _loading
                        ? const CircularProgressIndicator()
                        : const Text('Create Account'))),
          ])));
}

class EmailVerificationScreen extends ConsumerStatefulWidget {
  const EmailVerificationScreen({super.key, required this.email});
  final String email;
  @override
  ConsumerState<EmailVerificationScreen> createState() =>
      _EmailVerificationScreenState();
}

class _EmailVerificationScreenState
    extends ConsumerState<EmailVerificationScreen> {
  Timer? _poll;
  Timer? _countdown;
  int _seconds = 0;
  int _resends = 0;
  bool _loading = false;
  @override
  void initState() {
    super.initState();
    _poll =
        Timer.periodic(const Duration(seconds: 3), (_) => _check(silent: true));
  }

  @override
  void dispose() {
    _poll?.cancel();
    _countdown?.cancel();
    super.dispose();
  }

  Future<void> _check({bool silent = false}) async {
    if (_loading) return;
    if (!silent) setState(() => _loading = true);
    try {
      final verified =
          await ref.read(authProvider.notifier).checkEmailVerification();
      if (!mounted) return;
      if (verified) {
        await UserProfileService().markEmailVerified(
          FirebaseAuth.instance.currentUser!.uid,
        );
        if (!mounted) return;
        _snack(context, 'Email verified successfully.', success: true);
        await Future<void>.delayed(const Duration(seconds: 2));
        if (!mounted) return;
        context.go('/home');
      } else if (!silent) {
        _snack(context, 'Email not verified yet. Please check your inbox.');
      }
    } catch (_) {
    } finally {
      if (mounted && !silent) setState(() => _loading = false);
    }
  }

  Future<void> _resend() async {
    if (_seconds > 0 || _resends >= 3) return;
    setState(() {
      _loading = true;
      _resends++;
      _seconds = 30;
    });
    _countdown = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted || _seconds == 0) {
        t.cancel();
        return;
      }
      setState(() => _seconds--);
    });
    try {
      await ref.read(authProvider.notifier).sendEmailVerification();
      if (mounted) _snack(context, 'Verification email sent.', success: true);
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _changeEmail() async {
    final change = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
                title: const Text('Change email?'),
                content:
                    const Text("Are you sure? You'll need to sign up again."),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(c, false),
                      child: const Text('Cancel')),
                  FilledButton(
                      onPressed: () => Navigator.pop(c, true),
                      child: const Text('Change Email'))
                ]));
    if (change == true) {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await UserProfileService().delete(user.uid);
        await user.delete();
      }
      if (mounted) context.go('/email-signup');
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
      canPop: false,
      child: AuthScaffold(
          showBack: false,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Verify Your Email',
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            const Text("We've sent a verification link to:"),
            const SizedBox(height: 6),
            Text(
                widget.email.isEmpty
                    ? (FirebaseAuth.instance.currentUser?.email ?? '')
                    : widget.email,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text(
                'Please click the link in your email to confirm that you have access to this email address.'),
            const SizedBox(height: 28),
            SizedBox(
                height: 52,
                child: ElevatedButton(
                    onPressed: _loading ? null : _check,
                    child: _loading
                        ? const CircularProgressIndicator()
                        : const Text('Check Again'))),
            TextButton(
                onPressed:
                    _loading || _seconds > 0 || _resends >= 3 ? null : _resend,
                child: Text(_resends >= 3
                    ? 'Too many attempts. Try again in 24 hours.'
                    : _seconds > 0
                        ? 'Resend in ${_seconds}s'
                        : 'Resend Email')),
            TextButton(
                onPressed: _loading ? null : _changeEmail,
                child: const Text('Change Email')),
            TextButton.icon(
              onPressed: () => context.go('/home'),
              icon: const Icon(Icons.arrow_forward_rounded, size: 16, color: AppColors.mustardGold),
              label: const Text(
                'Explore App as Guest / Skip for now',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: AppColors.deepNavy,
                ),
              ),
            ),
            TextButton(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                if (context.mounted) context.go('/');
              },
              child: const Text('Sign Out', style: TextStyle(color: Colors.red)),
            ),
          ])));
}

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _hide = true;
  bool _loading = false;
  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _emailLogin() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await ref
          .read(authProvider.notifier)
          .signInWithEmail(_email.text.trim(), _password.text);
      if (mounted) context.go('/home');
    } on EmailVerificationRequiredException {
      if (mounted) context.go('/email-verification', extra: _email.text.trim());
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _google() async {
    setState(() => _loading = true);
    try {
      final c = await ref.read(authProvider.notifier).signInWithGoogle();
      if (!await UserProfileService().exists(c.user!.uid)) {
        throw Exception(
            'No account found. Please sign up or use a different method.');
      }
      if (mounted) context.go('/home');
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthScaffold(
      child: Form(
          key: _form,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Welcome Back',
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 28),
            SizedBox(
                height: 52,
                child: OutlinedButton.icon(
                    onPressed: _loading ? null : _google,
                    icon: const Icon(Icons.g_mobiledata, size: 28),
                    label: const Text('Continue with Google'))),
            const Padding(
                padding: EdgeInsets.symmetric(vertical: 20),
                child: Row(children: [
                  Expanded(child: Divider()),
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12),
                      child: Text('OR')),
                  Expanded(child: Divider())
                ])),
            _field(_email, 'Email Address', 'name@example.com',
                keyboard: TextInputType.emailAddress,
                validator: (v) => EmailValidator.isValid(v?.trim() ?? '')
                    ? null
                    : 'Please enter a valid email address'),
            const SizedBox(height: 14),
            _field(_password, 'Password', 'Enter your password',
                obscure: _hide,
                suffix: IconButton(
                    icon: Icon(_hide
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                    onPressed: () => setState(() => _hide = !_hide)),
                validator: (v) =>
                    (v ?? '').isEmpty ? 'Please enter your password' : null),
            Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                    onPressed: () => context.push('/forgot-password'),
                    child: const Text('Forgot Password?'))),
            SizedBox(
                height: 52,
                child: ElevatedButton(
                    onPressed: _loading ? null : _emailLogin,
                    child: _loading
                        ? const CircularProgressIndicator()
                        : const Text('Login'))),
            TextButton(
                onPressed: () => context.push('/mobile-login'),
                child: const Text('Login with Mobile')),
            TextButton.icon(
              onPressed: () => context.go('/home'),
              icon: const Icon(Icons.arrow_forward_rounded, size: 16, color: AppColors.mustardGold),
              label: const Text(
                'Explore App as Guest',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: AppColors.deepNavy,
                ),
              ),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text("Don't have an account?"),
              TextButton(
                  onPressed: () => context.push('/signup-method'),
                  child: const Text('Sign Up'))
            ])
          ])));
}

class ForgotPasswordScreen extends ConsumerStatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override
  ConsumerState<ForgotPasswordScreen> createState() =>
      _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends ConsumerState<ForgotPasswordScreen> {
  final _email = TextEditingController();
  bool _sent = false;
  bool _loading = false;
  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!EmailValidator.isValid(_email.text)) {
      _snack(context, 'Please enter a valid email address');
      return;
    }
    setState(() => _loading = true);
    try {
      await ref.read(authProvider.notifier).resetPassword(_email.text.trim());
      if (mounted) setState(() => _sent = true);
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthScaffold(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(_sent ? 'Check Your Email' : 'Reset Your Password',
            style: Theme.of(context)
                .textTheme
                .headlineMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Text(_sent
            ? "We've sent a password reset link to:\n${_email.text.trim()}\n\nClick the link in the email to reset your password. The link will expire in 1 hour."
            : "Enter the email address associated with your account. We'll send you a link to reset your password."),
        const SizedBox(height: 28),
        if (!_sent) ...[
          _field(_email, 'Email Address', 'name@example.com',
              keyboard: TextInputType.emailAddress),
          const SizedBox(height: 20),
          SizedBox(
              height: 52,
              child: ElevatedButton(
                  onPressed: _loading ? null : _send,
                  child: _loading
                      ? const CircularProgressIndicator()
                      : const Text('Send Reset Link')))
        ] else ...[
          SizedBox(
              height: 52,
              child: ElevatedButton(
                  onPressed: () => context.go('/login'),
                  child: const Text('Return to Login'))),
          TextButton(
              onPressed: _loading ? null : _send,
              child: const Text("Didn't receive email? Resend")),
          TextButton(
              onPressed: () => setState(() => _sent = false),
              child: const Text('Change Email'))
        ]
      ]));
}

class MobileEntryScreen extends ConsumerStatefulWidget {
  const MobileEntryScreen({super.key, required this.signup});
  final bool signup;
  @override
  ConsumerState<MobileEntryScreen> createState() => _MobileEntryScreenState();
}

class _MobileEntryScreenState extends ConsumerState<MobileEntryScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  bool _loading = false;
  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_form.currentState!.validate()) return;
    final phone = PhoneNumberValidator.normalize(_phone.text);
    setState(() => _loading = true);
    try {
      final profile = UserProfileService();
      final exists = await profile.phoneExists(phone);
      if (widget.signup && exists) {
        throw Exception(
            'This phone number is already registered. Try logging in instead.');
      }
      if (!widget.signup && !exists) {
        throw Exception(
            'No account found with this phone number. Please sign up.');
      }
      await ref.read(authProvider.notifier).verifyPhone(phone, (id) {
        if (mounted) {
          context.push('/otp',
              extra: OtpRouteParams(
                  verificationId: id,
                  phoneNumber: phone,
                  legalName: widget.signup ? _name.text.trim() : null,
                  isSignup: widget.signup));
        }
      }, (m) {
        if (mounted) _snack(context, m);
      }, (credential) async {
        if (widget.signup) {
          await profile.saveProfile(credential.user!,
              legalName: _name.text, provider: 'phone', phoneVerified: true);
        }
        if (mounted) context.go('/home');
      });
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthScaffold(
      child: Form(
          key: _form,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(widget.signup ? 'Create Your Account' : 'Login with Mobile',
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 28),
            if (widget.signup) ...[
              _field(_name, 'Legal Name', 'Enter your full legal name',
                  validator: legalNameError,
                  textCapitalization: TextCapitalization.words),
              const SizedBox(height: 14)
            ],
            _field(_phone, 'Mobile Number', '+91 Enter mobile number',
                keyboard: TextInputType.phone,
                formatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]'))
                ],
                validator: (v) => PhoneNumberValidator.isValid(v ?? '')
                    ? null
                    : 'Enter a valid 10-digit Indian mobile number'),
            const SizedBox(height: 24),
            SizedBox(
                height: 52,
                child: ElevatedButton(
                    onPressed: _loading ? null : _send,
                    child: _loading
                        ? const CircularProgressIndicator()
                        : Text(widget.signup ? 'Continue' : 'Send OTP'))),
            if (!widget.signup)
              TextButton(
                  onPressed: () => context.go('/login'),
                  child: const Text('Login with Email'))
          ])));
}

class ConfirmNameScreen extends StatefulWidget {
  const ConfirmNameScreen({super.key, required this.user});
  final User user;
  @override
  State<ConfirmNameScreen> createState() => _ConfirmNameScreenState();
}

class _ConfirmNameScreenState extends State<ConfirmNameScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name;
  bool _loading = false;
  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.user.displayName ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await UserProfileService()
          .saveProfile(widget.user, legalName: _name.text, provider: 'google');
      if (mounted) context.go('/home');
    } catch (e) {
      if (mounted) _snack(context, friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext c) => AuthScaffold(
      child: Form(
          key: _form,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Confirm Your Name',
                style: Theme.of(c)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('Please enter the name you use for legal services.'),
            const SizedBox(height: 24),
            _field(_name, 'Legal Name', 'Enter your full legal name',
                validator: legalNameError),
            const SizedBox(height: 24),
            ElevatedButton(
                onPressed: _loading ? null : _save,
                child: _loading
                    ? const CircularProgressIndicator()
                    : const Text('Continue'))
          ])));
}

Widget _field(TextEditingController controller, String label, String hint,
        {String? Function(String?)? validator,
        TextInputType? keyboard,
        bool obscure = false,
        Widget? suffix,
        List<TextInputFormatter>? formatters,
        TextCapitalization textCapitalization = TextCapitalization.none}) =>
    TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: keyboard,
        obscureText: obscure,
        inputFormatters: formatters,
        textCapitalization: textCapitalization,
        style: const TextStyle(color: AppColors.deepNavy, fontSize: 15),
        decoration: InputDecoration(
            labelText: label, hintText: hint, suffixIcon: suffix));
void _snack(BuildContext context, String message, {bool success = false}) =>
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
          content: Text(message),
          backgroundColor: success ? AppTheme.success : AppTheme.error));
String friendlyError(Object error) {
  final text = error.toString().replaceFirst('Exception: ', '');
  if (text.contains('network-request-failed')) {
    return 'No internet connection. Please try again.';
  }
  if (text.contains('too-many-requests')) {
    return 'Too many login attempts. Try again in 24 hours.';
  }
  if (text.contains('wrong-password') || text.contains('invalid-credential')) {
    return 'Incorrect password. Please try again.';
  }
  if (text.contains('user-not-found')) {
    return 'Email not found. Please sign up.';
  }
  if (text.contains('user-disabled')) {
    return 'This account has been disabled. Contact support.';
  }
  return text;
}
